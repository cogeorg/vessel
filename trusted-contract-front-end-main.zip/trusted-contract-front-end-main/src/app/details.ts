export class Details {

    constructor(
      public firstname: string,
      public lastname: string,
      public number: string,
      public pin: string,
      public confirmPin: string,
    ) {  }
  
  }