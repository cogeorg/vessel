import { SwalHelper } from './swal-helper';

describe('SwalHelper', () => {
  it('should create an instance', () => {
    expect(new SwalHelper()).toBeTruthy();
  });
});
