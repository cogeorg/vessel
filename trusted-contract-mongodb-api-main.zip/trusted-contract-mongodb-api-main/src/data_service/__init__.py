"""
Data service for Trusted Contract.
"""
