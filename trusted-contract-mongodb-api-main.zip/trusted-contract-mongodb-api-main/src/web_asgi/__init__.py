"""
The web server and its endpoints that exposes the various services of Wallet
backend.
"""
