"""
A collection of various helpers, convenience libraries or otherwise commonly
reused code for the Nautilus Wallet backend.
"""
