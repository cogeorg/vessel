from typing import NewType

WalletAddress = NewType("WalletAddress", str)
"""
A type for wallet addresses.
"""
