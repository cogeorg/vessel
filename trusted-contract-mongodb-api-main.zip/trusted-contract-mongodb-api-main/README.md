# Trusted COntract API

An HTTP server for Trusted Contract powered by [FastAPI][fastapi] and
the [uvicorn ASGI server][uvicorn].